#include "PortabilityImpl.hh"
#ifdef LOG4CPP_HAVE_IO_H
#    include <io.h>
#endif
#ifdef LOG4CPP_HAVE_UNISTD_H
#    include <unistd.h>
#endif

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <log4cpp/DailyRollingFileAppender.hh>
#include <log4cpp/Category.hh>
#include <log4cpp/FactoryParams.hh>
#include <memory>
#include <stdio.h>
#ifdef LOG4CPP_HAVE_SSTREAM
#include <sstream>
#endif

namespace log4cpp {

DailyRollingFileAppender::DailyRollingFileAppender(const std::string& name,
                                             const std::string& fileName, 
                                             size_t maxFileSize, 
                                             unsigned int maxBackupIndex,
                                             bool append,
                                             mode_t mode) :
        FileAppender(name, fileName, append, mode),
        _maxBackupIndex(maxBackupIndex),
        _maxFileSize(maxFileSize)
{
    	struct stat statBuf;
	int res;
	time_t t;

	res = ::stat(fileName.c_str(), &statBuf);
	if (res < 0) 
	{
		t = time(NULL);
    	}
	else 
	{
        	t = statBuf.st_mtime;
    	}
   	localtime_r(&t, &_logsTime);
}
void DailyRollingFileAppender::setMaxBackupIndex1(unsigned int maxBackups) 
{ 
        _maxBackupIndex = maxBackups; 
}
    
unsigned int DailyRollingFileAppender::getMaxBackupIndex1() const 
{ 
        return _maxBackupIndex; 
}

void DailyRollingFileAppender::setMaximumFileSize1(size_t maxFileSize) 
{
        _maxFileSize = maxFileSize;
}

size_t DailyRollingFileAppender::getMaxFileSize1() const 
{ 
        return _maxFileSize; 
}
void DailyRollingFileAppender::rollOver1()
{
    std::ostringstream stream;
    std::ostringstream streamBackUp;
    for(int i = 1; i <=  _maxBackupIndex;++i)
    {
        stream.str("");
        streamBackUp.str("");
        streamBackUp <<_fileName << "." << i;
        if(!access(streamBackUp.str().c_str(),F_OK))
        {
            stream<<_fileName << "." << i << "."<<_logsTime.tm_year + 1900 << std::setfill('0') <<
                    std::setw(2) << _logsTime.tm_mon + 1 << std::setw(2) << _logsTime.tm_mday << std::ends;
            ::remove(stream.str().c_str());
            ::rename(streamBackUp.str().c_str(), stream.str().c_str());
        }
        else
        {
            break;
        }
    }
    stream.str("");
    stream<<_fileName<<  "." << _logsTime.tm_year + 1900 << std::setfill('0') <<
            std::setw(2) << _logsTime.tm_mon + 1 << std::setw(2) << _logsTime.tm_mday <<std::ends;
    ::remove(stream.str().c_str());
    ::rename(_fileName.c_str(), stream.str().c_str());
    _fd = ::open(_fileName.c_str(), _flags, _mode);
}
void DailyRollingFileAppender::_append(const LoggingEvent& event) 
{
        struct tm now;
	time_t t = time(NULL);

    	if (localtime_r(&t, &now) != NULL) 
	{
        	if ((now.tm_year != _logsTime.tm_year) ||
            	(now.tm_mon != _logsTime.tm_mon) ||
            	(now.tm_mday != _logsTime.tm_mday)) 
		{
            		rollOver1();
            		_logsTime = now;
        	}
    	}
    	log4cpp::FileAppender::_append(event);
}
std::auto_ptr<Appender> create_dailyroll_file_appender(const FactoryParams& params)
{
	std::string name, filename;
	bool append = true;
	mode_t mode = 664;
      	int max_file_size = 0, max_backup_index = 0;
      	params.get_for("dailyrool file appender").required("name", name)("filename", filename)("max_file_size", max_file_size)
                                                     ("max_backup_index", max_backup_index)
                                          .optional("append", append)("mode", mode);

      	return std::auto_ptr<Appender>(new DailyRollingFileAppender(name, filename, max_file_size, max_backup_index, append, mode));
}
}

