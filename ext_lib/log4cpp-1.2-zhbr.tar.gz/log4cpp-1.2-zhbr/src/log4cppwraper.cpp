#include <log4cpp/log4cppwraper.h>
log4cpp::Category* log4cpp::Log4CppIni::root = NULL;
