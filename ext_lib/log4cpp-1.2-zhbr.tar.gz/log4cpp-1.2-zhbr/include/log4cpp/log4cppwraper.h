/*
 * Copyright (c) 2014, �����к㲩�����ֵ����Ƽ����޹�˾
 * All rights reserved.
 *
 * �ļ����ƣ�project/folder/file.h
 * ����������������Ҫ��log4c���м򵥵ķ�װ�� �ò���ԭ��ͷ�ļ���ʵ���ļ��Ƿֿ��ģ�
 * ��Ϊ�б������cpp�ļ���������ȥ���鷳���ʰ�ʵ���ļ��ϲ���ͷ�ļ��С�Log4cInitFiniԭΪ����ģʽ
 *
 * ��ǰ�汾��1.0
 * �� �ߣ�������
 * ������ڣ�2014��09��03��
 */
#ifndef LOG4CPPWRAPER_H
#define LOG4CPPWRAPER_H

#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "log4cpp/Category.hh"
#include "log4cpp/RollingFileAppender.hh"
#include "log4cpp/PropertyConfigurator.hh"
#include "log4cpp/PatternLayout.hh"

#define FORMAT_LENGTH   512
#define LOG_LENGTH      512 * 10

#include <sstream>
using namespace std;

namespace log4cpp
{
    /**
     * @brief ͨ������Ĺ��캯������������������log4c�ĳ�ʼ���ͷ���ʼ�����������ֻ���и����һ������
     */
    class Log4CppIni
    {
    private:

        Log4CppIni(){
        }
        ~Log4CppIni() {
        }
    public:
        static const  bool    isFaild() {
            return !root;
        }
      static bool initLog(const string& pathConfig,const string& logName)
        {
         try
            {
            
                log4cpp::PropertyConfigurator::configure(pathConfig,logName);
                root =  &log4cpp::Category::getRoot();
                return true;
            }
         catch (log4cpp::ConfigureFailure& f)
            {
                std::cout << "Configure Log4cpp Problem:" << f.what() << std::endl;
                root = NULL;
                throw f;
                return false;
            }
        }

      static bool initLog(int argc, char **argv)
        {
            try
            {
                if(argc < 1)
                {
                    return false;
                }
                string strCat = argv[0];
                string strPreFix = "";
                string::size_type pos = strCat.find_last_of("/");
                if(pos != string::npos)
                {
                    strPreFix = strCat.substr(0,pos) + "/";
                    strCat = strCat.substr(pos + 1);
                    
                }
                log4cpp::PropertyConfigurator::configure(strPreFix + "../config/log4cpp.conf",strCat);
                root =  &log4cpp::Category::getRoot();
                return true;
            }
            catch (log4cpp::ConfigureFailure& f)
            {
                std::cout << "Configure Log4cpp Problem:" << f.what() << std::endl;
                root = NULL;
                throw f;
                return false;
            }
        }

        static log4cpp::Category* getCategory()
        {
            return root;
        }


    private:
        static log4cpp::Category* root;
        //static bool    m_bInitFaild;//��ʶ��ʼ���Ƿ�ɹ�
    };


    static void LogMessage(Priority::Value priority,
                           const char *file, int line, const char *function,
                           const char *format, ...)
    {
        ostringstream osFormator;
        osFormator << "[" << file << "]";
        osFormator << "[" << line << "]" <<
        "[" << function << "]" << format;
        //if log4c failed to initialize ifself or get a invalid category,
        //the log will be write on stderr or stdout.
        va_list va;
        va_start(va, format);
        Log4CppIni::getCategory()->logva(priority,osFormator.str().c_str(),va);
        va_end(va);
    }
    static CategoryStream LogStream(Priority::Value priority,
                                    const char *file, int line, const char *function)
   {
            CategoryStream stream = Log4CppIni::getCategory()->getStream(priority);
            stream << "[" << file << "]" << "[" << line << "]" <<  "[" << function << "]";
          return stream;
    }

#define LOG_FATAL_STREAM() \
    LogStream(log4cpp::Priority::FATAL, basename(__FILE__), __LINE__, __FUNCTION__)
#define LOG_ALERT_STREAM() \
    LogStream(log4cpp::Priority::ALERT, basename(__FILE__), __LINE__, __FUNCTION__)
#define LOG_CRIT_STREAM() \
    LogStream(log4cpp::Priority::CRIT, basename(__FILE__), __LINE__, __FUNCTION__)
#define LOG_ERROR_STREAM() \
    LogStream(log4cpp::Priority::ERROR, basename(__FILE__), __LINE__, __FUNCTION__)
#define LOG_WARN_STREAM() \
    LogStream(log4cpp::Priority::WARN, basename(__FILE__), __LINE__, __FUNCTION__)
#define LOG_NOTICE_STREAM() \
    LogStream(log4cpp::Priority::NOTICE, basename(__FILE__), __LINE__, __FUNCTION__)
#define LOG_INFO_STREAM() \
    LogStream(log4cpp::Priority::INFO, basename(__FILE__), __LINE__, __FUNCTION__)
#define LOG_DEBUG_STREAM() \
    LogStream(log4cpp::Priority::DEBUG, basename(__FILE__), __LINE__, __FUNCTION__)
#define LOG_NOTSET_STREAM() \
    LogStream(log4cpp::Priority::NOTSET, basename(__FILE__), __LINE__, __FUNCTION__)

#define LOG_FATAL(format, args...) \
    LogMessage(log4cpp::Priority::FATAL, basename(__FILE__), __LINE__, __FUNCTION__, format, ##args);
#define LOG_ALERT(format, args...) \
    LogMessage(log4cpp::Priority::ALERT, basename(__FILE__), __LINE__, __FUNCTION__, format, ##args);
#define LOG_CRIT(format, args...) \
    LogMessage(log4cpp::Priority::CRIT, basename(__FILE__), __LINE__, __FUNCTION__, format, ##args);
#define LOG_ERROR(format, args...) \
    LogMessage(log4cpp::Priority::ERROR, basename(__FILE__), __LINE__, __FUNCTION__, format, ##args);
#define LOG_WARN(format, args...) \
    LogMessage(log4cpp::Priority::WARN, basename(__FILE__), __LINE__, __FUNCTION__, format, ##args);
#define LOG_NOTICE(format, args...) \
    LogMessage(log4cpp::Priority::NOTICE, basename(__FILE__), __LINE__, __FUNCTION__, format, ##args);
#define LOG_INFO(format, args...) \
    LogMessage(log4cpp::Priority::INFO, basename(__FILE__), __LINE__, __FUNCTION__, format, ##args);
#define LOG_DEBUG(format, args...) \
    LogMessage(log4cpp::Priority::DEBUG, basename(__FILE__), __LINE__, __FUNCTION__, format, ##args);
#define LOG_NOTSET(format, args...) \
    LogMessage(log4cpp::Priority::NOTSET, basename(__FILE__), __LINE__, __FUNCTION__, format, ##args);

}

#endif // LOG4CWRAPER_H
