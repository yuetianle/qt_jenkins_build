#ifndef _LOG4CPP_DAILYROLLINGFILEAPPENDER_HH
#define _LOG4CPP_DAILYROLLINGFILEAPPENDER_HH

#include <log4cpp/Portability.hh>
#include <log4cpp/FileAppender.hh>
#include <string>
#include <stdarg.h>
#include <iomanip>

namespace log4cpp {
    class LOG4CPP_EXPORT DailyRollingFileAppender : public FileAppender {
        public:
        DailyRollingFileAppender(const std::string& name, 
                            const std::string& fileName,
                            size_t maxFileSize = 10*1024*1024, 
                            unsigned int maxBackupIndex = 1,
                            bool append = true,
                            mode_t mode = 00644);

        virtual void setMaxBackupIndex1(unsigned int maxBackups);
        virtual unsigned int getMaxBackupIndex1() const;
        virtual void setMaximumFileSize1(size_t maxFileSize);
        virtual size_t getMaxFileSize1() const;

        virtual void rollOver1();

        protected:
        virtual void _append(const LoggingEvent& event);

        unsigned int _maxBackupIndex;
        size_t _maxFileSize;
        //unsigned int _maxDaysToKeep;
        struct tm _logsTime;
    };
}

#endif // _LOG4CPP_DAILYROLLINGFILEAPPENDER_HH
